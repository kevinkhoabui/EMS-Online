export class Salary {
  salary_id: number;
  salary_employee_id: string;
  salary_working_days: string;
  salary_basic: string;
  salary_hra: string;
  salary_mediclaim: string;
  salary_ta: string;
  salary_da: string;
  salary_reimbursement: string;
  salary_ca: string;
  salary_others: string;
  salary_dpf: string;
  salary_dtax: string;
  salary_desc: string;
  salary_month: string;
  salary_total: string;
  salary_dedc: string;
}