export class State {
  id: number;
  firstName: string;
  lastName: string;
  emailId: string;
  active: boolean;
}
